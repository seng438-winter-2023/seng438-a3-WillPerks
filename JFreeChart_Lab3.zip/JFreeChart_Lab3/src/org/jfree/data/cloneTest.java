package org.jfree.data;

import static org.junit.Assert.*;

import org.junit.Test;

public class cloneTest {


	//testing with null values
	@Test(expected = Exception.class)
	public void arrayContainingNullValues() {
		double[][] test = {{(Double)null},{(Double)null} };
		DataUtilities.clone(test);
		
	}

	//testing with null values
		@Test(expected = Exception.class)
		public void arrayofNullArrays() {
			double[][] test = {null, null };
			DataUtilities.clone(test);
			
		}
	
	
	//testing with null array
	@Test(expected = Exception.class)
	public void nullArray() {
		double[][] test = null;
		DataUtilities.clone(test);
			
	}
	
	@Test
	public void validArray() {
		double[][] test = {{}};
		DataUtilities.clone(test);
			 
	}	
	
	@Test
	public void testingWithEmptyArrays() {
		double[][] expected = {{}}; // Creating empty test double array
		
		double[][] actual = DataUtilities.clone(expected); // Creating array with empty test double array with createnumberarray2d method
		assertArrayEquals(expected[0], actual[0],.000000001d);
	}
	
	
	@Test
	public void testingWithSmallArrays() {
		double[][] expected = {{1,2},{1,2}}; // Creating empty test double array
		
		double[][] actual = DataUtilities.clone(expected); // Creating array with empty test double array with createnumberarray2d method
		assertArrayEquals(expected[0], actual[0],.000000001d);
		assertArrayEquals(expected[1], actual[1],.000000001d);
	}
	
	@Test
	public void testingWithLargeArrays() {
		double[][] expected = {{1.0, 2.0, 3.0}, {1.0, 2.0, 3.0}, {1.0, 2.0, 3.0 }}; // Creating empty test double array
		
		double[][] actual = DataUtilities.clone(expected); // Creating array with empty test double array with createnumberarray2d method
		assertArrayEquals(expected[0], actual[0],.000000001d);
		assertArrayEquals(expected[1], actual[1],.000000001d);
		assertArrayEquals(expected[2], actual[2],.000000001d);
		
	}
	
}
