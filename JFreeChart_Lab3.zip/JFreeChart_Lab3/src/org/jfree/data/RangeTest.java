package org.jfree.data;

import static org.junit.Assert.*;

import java.security.InvalidParameterException;

import org.jfree.data.Range;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.*;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;





@RunWith(Enclosed.class)
public class RangeTest {
	
	
    private static Range exampleRange;
    private static Range upperNaNRange;
    private static Range lowerNaNRange;
    
	//Creating test Range objects to be used in testing
    @BeforeClass public static void setUpBeforeClass() throws Exception {
    	exampleRange = new Range(-1, 1); // first is lower than second, range should be valid
    	upperNaNRange = new Range(-1, Double.NaN); //upper value is not a value
    	lowerNaNRange = new Range(Double.NaN, 1); //lower value of range is not a value
   
    	
    }


    @Before
    public void setUp() throws Exception {
    	
    	
    }
    
   
   
	//Testing the getLength() function in the Range class
   public static class lengthTesting {
	   
	   //Testing the getLength function with -1 and 1 as the Range, the resulting length should be 2
	   @Test
	    public void lengthShouldBeTwo() {
	    	assertEquals("The length of -1 and 1 should be 2", 
	    	        2.0, exampleRange.getLength(), .000000001d);
	    }
	   
	   //Testing the getLength function with 4 and 3 as the Range, the function should throw an IllegalArgumentException
	   @Test(expected = IllegalArgumentException.class)
	   public void lengthShouldNotBeCalculated() {
		    Range a = new Range(4, 3);
		    a.getLength(); 
	    	
	    }
	   
		//Testing the getLength function with 4 and 4 as the Range, the resulting length should be 0
	   @Test
	   public void lengthShouldBeZero() {
		    Range b  = new Range(4, 4);
		    assertEquals("Length should be zero", 
	    	        0.0, exampleRange.getLength(), .000000001d);
	    	
	    }
	   
   }

    
 //Testing the getCentralLength() function in the Range class   
 //This tests if the central value is 0 with range -1 and 1 
    public static class centralValueTesting{
    	 @Test
    	 public void centralValueShouldBeZero() {
    	     assertEquals("The central value of -1 and 1 should be 0",
    	      0, exampleRange.getCentralValue(), .000000001d);
    	  }
    	 
    	 
    }
   
    //Testing the contains() function in the Range class   
    public static class containsTesting {
    	
    		// This one tests if zero is contained in -1 and 1
    		//should assert true
    	 	@Test
    	    public void containsInRange() {
    	    	assertTrue("Zero should be in range -1 and 1",exampleRange.contains(0.0));
    	    }
    	    
    	 // This one tests if the lower bound is contained in -1 and 1
    	 	//should assert true
    	 	@Test
    	 	public void containsLowerBound() {
    	    	assertTrue("-1 should be in range -1 and 1",exampleRange.contains(-1.0));
    	    }
    	 	
    	 // This one tests if the upper bound is contained in -1 and 1
    	 	//should assert true
    	 	@Test
    	 	public void containsUpperBound() {
    	    	assertTrue("1 should be in range -1 and 1",exampleRange.contains(1.0));
    	    }
    	 	
    	 	@Test
    	 	public void containsNaN() {
    	    	assertFalse("Double.NaN should be in range -1 and 1",exampleRange.contains(Double.NaN));
    	    }
    	 	
    	 	 	
    	    
    	   // This one test if the values lower than the lower bound is  not contained in -1 and 1
    	 	//should assert false
    	    @Test
    	    public void containsLessThanLowerBound() {
    	    	assertFalse("-3 should not be in range -1 and 1",exampleRange.contains(-3.0));
    	    }
    	    
    	    // This one test if the values greater than the upper bound is  not contained in -1 and 1
    	  //should assert false
    	    @Test
    	    public void containsMoreThanUpperBound() {
    	    	assertFalse("3 should not be in range -1 and 1",exampleRange.contains(3.0));
    	    }
    	    
    	    @Test
    	    public void containsMoreThanUpperBoundWhenUpperIsNaN() {
    	    	assertFalse("3 should not be in range -1 and NaN",upperNaNRange.contains(3.0));
    	    }
    	    
    	    @Test
    	    public void containsLessThanLowerBoundWhenLowerIsNaN() {
    	    	assertFalse("-3 should not be in range NaN and 1",lowerNaNRange.contains(-3.0));
    	    }
    	    
    	    
    	    
    }
    
	//Testing the intersects() function in the Range class 
    public static class intersectWithRangeAsArgumentTest {
    	
    	//testing with boundaries  within -1 and 1
   	 	//should  be valid
    	 @Test
    	    public void intersectWithValuesWithinBoundary() {
    	    	assertTrue("-0.5 and 0 should intersect -1 and 1",
    	    	        exampleRange.intersects(new Range(-0.5,0)));
    	    }
    	 
    	//testing with range boundaries 
    	 //should not be valid
    	 @Test
    	 public void intersectWithRangeBoundaries() {
    		 assertTrue("-1 and 1 should intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-1,1)));
 	    
    	 }
    	 
    	 //testing with only lower value in range
    	 //should assert false
    	 @Test
    	 public void intersectWithOnlyLowerValueInRange() {
 	    	assertFalse("0 and 5 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(0,5)));
 	    }
    	 
    	 //testing with only upper value in range
    	 //should assert false
    	 @Test
    	 public void intersectWithOnlyUpperValueInRange() {
 	    	assertFalse("-5 and 0 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-5,0)));
    	 }
 	    
    	 //testing with both boundaries greater than 1
    	 //should assert false
    	 @Test
    	 public void intersectWithBothValuesMoreThanUpperBoundary() {
 	    	assertFalse("3 and 10 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-1,1)));
 	    }
    	 
    	 //testing with both boundaries less than -1
    	 //should assert false
    	 @Test
    	 public void intersectWithBothValuesLessThanLowerBoundary() {
 	    	assertFalse("-5 and -3 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-5,-3)));
 	    	
 	    }
    	 
    	 
    	 //testing with lower boundary less than -1 and upper boundary greater than 1
    	 //should assert false
    	 @Test
    	 public void intersectWithBothValuesLessThanLowerBoundaryAndGreaterThanUpperBoundary() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-2,2)));
 	    	
 	    }
    	 
    	 
    	//testing with lower boundary as not a number and upper boundary as 0
    	 //should assert false
    	 @Test
    	 public void intersectWithFirstValueNaN() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(Double.NaN,0)));
 	    	
 	    }
    	 
		//testing with lower boundary as 0 and upper boundary as not a number
    	 //should assert false
    	 @Test
    	 public void intersectWithSecondValueNaN() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(0,Double.NaN)));
 	    	
 	    }
    	 
    	 
    	
    }

    //Testing the constrain() function in the Range class 
    public static class constrainTest {

    	@Test
		//Testing the constrain value with range of -1 and 1, should be 0
    	public void constrainForValueInRange() {
    		assertEquals("The constrain value of -1 and 1 should be 0",
    	    	      0, exampleRange.constrain(0), .000000001d);
    	}
    	
		//Testing the constrain value with range of -1 and 1, should be -1
    	@Test
    	public void constrainForValueLowerThanLowerBound() {
    		assertEquals("The constrain value of -1 and 1 should be -1",
    	    	      -1.0, exampleRange.constrain(-3.0), .000000001d);
    	}
    	
		//Testing the constrain value with range of -1 and 1, should be 1
    	@Test
    	public void constrainForValueLowerThanUpperBound() {
    		assertEquals("The constrain value of -1 and 1 should be 1",
    	    	      1.0, exampleRange.constrain(3.0), .000000001d);
    	}
    	
		//Testing the constrain value with rot values
    	@Test
    	public void constrainForNaN() {
    		assertTrue(Double.isNaN(exampleRange.constrain(Double.NaN)));
    	}
    	
    	
    	
    }
    
    //Testing the isNaN() function in the Range class
    public static class isNanRangeTest {

		//Testing the range -1 and 1 boundaries to see if they are both not a number
		//Should be false
    	@Test
    	public void testForValidRange() {
    		assertFalse((new Range(-1,1)).isNaNRange());
    	}
    	
		//Testing the range -1 and not a number boundaries to see if they are both not a number
		//Should be false
    	@Test
    	public void testForUpperBoundNaNOnly() {
    		assertFalse((new Range(-1,Double.NaN)).isNaNRange());
    	}
    	
		//Testing the range not a number and 1 boundaries to see if they are both not a number
		//Should be false
    	@Test
    	public void testForLowerBoundNaNOnly() {
    		assertFalse((new Range(Double.NaN,1)).isNaNRange());
    	}
    	
    	//Testing the range not a number and not a number boundaries to see if they are both not a number
		//Should be true
    	@Test
    	public void testForBothBoundsNaN() {
    		assertTrue((new Range(Double.NaN,Double.NaN)).isNaNRange());
    	}
    }

    //Testing the getLowerBound() function in the Range class
    public static class boundaryTesting{
    	
    	//checks if lower bound is -1
    	@Test
        public void lowerBoundShouldBeNegativeOne() {
        	assertEquals("The lower bound of -1 and 1 should be -1",
        	        -1.0, exampleRange.getLowerBound(), .000000001d);
        }
        
    	
    	//checks if upper bound is 1
        @Test
        public void upperBoundShouldBeOne() {
        	assertEquals("The upper bound of -1 and 1 should be 1",
        	        1.0, exampleRange.getUpperBound(), .000000001d);
        }
    }
    
	//Testing the toString() function in the Range class
   public static class toStringTest{

		//Testing toString with valid range
	   @Test
	   public void forValidRange() {
		   assertEquals("It should be Range[-1.0,1.0]","Range[-1.0,1.0]", exampleRange.toString());
	   }
	   		
	   //Testing with upper bound not being a number

	   @Test
	   public void forUpperBoundBeingNaNRange() {
		   assertEquals("It should be Range[-1.0,NaN]","Range[-1.0,NaN]", upperNaNRange.toString());
	   }
	   
	   //Testing with lower bound not being a number
	   @Test
	   public void forLowerBoundBeingNaNRange() {
		   assertEquals("It should be Range[NaN,1.0]","Range[NaN,1.0]", lowerNaNRange.toString());
	   }
   }
    
   	//Testing the intersect() function in the Range class
    public static class intersectingTest {
    	
    	
    	//testing range -1 and 1 intersecting -0.5 and 0
   	 	//should  be valid
    	 @Test
    	    public void intersectWithValuesWithinBoundary() {
    	    	assertTrue("-0.5 and 0 should intersect -1 and 1",
    	    	        exampleRange.intersects(-0.5, 0));
    	    }
    	 
    	//testing range -1 and 1 intersecting -1 and 1
   	 	//should  be valid
    	 @Test
    	 public void intersectWithRangeBoundaries() {
    		 assertTrue("-1 and 1 should intersect -1 and 1",
 	    	        exampleRange.intersects(-1, 1));
 	    
    	 }
    	 
    	 //testing range -1 and 1 intersecting 0 and 5
   	 	//should be false
    	 @Test
    	 public void intersectWithOnlyLowerValueInRange() {
 	    	assertFalse("0 and 5 should not intersect -1 and 1",
 	    	        exampleRange.intersects(0, 5));
 	    }
    	 
    	 //testing range -1 and 1 intersecting -5 and 0
   	 	//should be false
    	 @Test
    	 public void intersectWithOnlyUpperValueInRange() {
 	    	assertFalse("-5 and 0 should not intersect -1 and 1",
 	    	        exampleRange.intersects(-5, 0));
    	 }
 	    
    	 //testing range -1 and 1 intersecting 3 and 10
   	 	//should  be false
    	 @Test
    	 public void intersectWithBothValuesMoreThanUpperBoundary() {
 	    	assertFalse("3 and 10 should not intersect -1 and 1",
 	    	        exampleRange.intersects(3, 10));
 	    }
    	 
    	//testing range -1 and 1 intersecting -5 and -3
   	 	//should  be false
    	 @Test
    	 public void intersectWithBothValuesLessThanLowerBoundary() {
 	    	assertFalse("-5 and -3 should not intersect -1 and 1",
 	    	        exampleRange.intersects(-5, -3));
 	    	
 	    }
    	 
    	 //testing range -1 and 1 intersecting 5 and 0
   	 	//should  be false
    	 @Test
    	 public void intersectWithFirstValueGreaterSecondValue() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(5, 0));
 	    	
 	    }
    	 
		//testing range -1 and 1 intersecting -2 and -2
   	 	//should  be false
    	 @Test
    	 public void intersectWithBothValuesLessThanLowerBoundaryAndGreaterThanUpperBoundary() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(-2, -2));
 	    	
 	    }
    	 
    	 
    	//testing range -1 and 1 intersecting not a number and 0
   	 	//should  be false
    	 @Test
    	 public void intersectWithFirstValueNaN() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(Double.NaN, 0));
 	    	
 	    }
    	 
		//testing range -1 and 1 intersecting 0 and not a number
   	 	//should  be false
    	 @Test
    	 public void intersectWithSecondValueNaN() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(0, Double.NaN));
 	    	
 	    } 
    	 
    }
    
    
   	//Testing the combine() function in the Range class
	   public static class combineTest {

		//Testing combine with valid range
    	@Test
    	public void forValidRanges() {
    		
    		Range newRange = Range.combine( exampleRange, new Range(3 ,5));
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 5,newRange.getUpperBound(), .000000001d );
    	}
    	

		//Testing combine with the first range null
    	@Test
    	public void forRangesWithFirstRangeNull() {
    		Range newRange = Range.combine(null,  exampleRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing combine with the second range null
    	@Test
    	public void forRangesWithSecondRangeNull() {
    		Range newRange = Range.combine( exampleRange, null);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing combine with both range null
    	@Test
    	public void forRangesWithBothRangesNull() {
    		Range newRange = Range.combine( null , null);
    		assertNull(newRange);
    	}
    	
    }
    
	//Testing the combineIgnoringNaN() function in the Range class
    public static class combineIgnoringNaNTest {

		//Testing with valid ranges as inputs
    	@Test
    	public void forValidRanges() {
    		
    		Range newRange = Range.combineIgnoringNaN( exampleRange, new Range(3 ,5));
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 5,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with the first range null
    	@Test
    	public void forRangesWithFirstRangeNull() {
    		Range newRange = Range.combineIgnoringNaN(null,  exampleRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with the second range null
    	@Test
    	public void forRangesWithSecondRangeNull() {
    		Range newRange = Range.combineIgnoringNaN( exampleRange, null);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with both ranges null
    	@Test
    	public void forRangesWithBothRangesNull() {
    		Range newRange = Range.combineIgnoringNaN( null , null);
    		assertNull(newRange);
    	}
    	
		//Testing with second range lower bound not being a number
    	@Test
    	public void forRangesWithSecondRangeWithLowerBoundNaN() {
    		Range newRange = Range.combineIgnoringNaN(exampleRange , lowerNaNRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	//Testing with the first range lower bound not being a number
    	@Test
    	public void forRangesWithFirstRangeWithLowerBoundNaN() {
    		Range newRange = Range.combineIgnoringNaN(lowerNaNRange, exampleRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
		
		//Testing with the first range upper bound not being a number
    	@Test
    	public void forRangesWithFirstRangeWithUpperBoundNaN() {
    		Range newRange = Range.combineIgnoringNaN(upperNaNRange , exampleRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with the second range upper bound not being a number
    	@Test
    	public void forRangesWithSecondRangeWithUpperBoundNaN() {
    		Range newRange = Range.combineIgnoringNaN(exampleRange, upperNaNRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with the one range upper bound not being a number and one range null
    	@Test
    	public void forRangesWithOneRangeWithUpperBoundNaNAndOneNullRange() {
    		Range newRange = Range.combineIgnoringNaN(null, upperNaNRange );
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( Double.NaN,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with the one range lower bound not being a number and one range null
    	@Test
    	public void forRangesWithOneRangeWithLowerBoundNaNAndOneNullRange() {
    		Range newRange = Range.combineIgnoringNaN( lowerNaNRange, null);
    		assertEquals( Double.NaN,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with the first range null and second range not being a number 
    	@Test
    	public void forRangesWithFirstRangeNUllAndSecondRangeWithNaNValues() {
    		Range newRange = Range.combineIgnoringNaN( null, new Range(Double.NaN, Double.NaN));
    		assertNull(newRange);
    	}
    	
		//Testing with the first range null and second range not being a number
    	@Test
    	public void forRangesWithSecondRangeNullAndSecondRangeWithNaNValues() {
    		Range newRange = Range.combineIgnoringNaN(new Range(Double.NaN, Double.NaN), null);
    		assertNull(newRange);
    	}
    	
		//Testing with the lower bounds of ranges not being a number
    	@Test
    	public void forRangesWithNaNLowerBounds() {
    		Range newRange = Range.combineIgnoringNaN(new Range(Double.NaN, 1), new Range(Double.NaN, 3) );
    		assertEquals( Double.NaN,newRange.getLowerBound(), .000000001d );
    		assertEquals( 3.0,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with ranges with upper bounds not being a number
    	@Test
    	public void forRangesWithNaNUpperBounds() {
    		Range newRange = Range.combineIgnoringNaN(new Range( 1, Double.NaN), new Range( 3, Double.NaN) );
    		assertEquals(1.0 ,newRange.getLowerBound(), .000000001d );
    		assertEquals( Double.NaN,newRange.getUpperBound(), .000000001d );
    	}
    	
		//Testing with ranges with bounds not being a number
    	@Test
    	public void forRangesWithNaNBounds() {
    		Range newRange = Range.combineIgnoringNaN(new Range( Double.NaN, Double.NaN), new Range( Double.NaN, Double.NaN) );
    		assertNull(newRange);
    	}
    }
    
	//Testing the hashCode() function in the Range class
    public static class hashCodeTest{

		//Testing with valid ranges
    	@Test
    	public void forValidRange() {
    		assertEquals(-31457280, exampleRange.hashCode());
    	}
    	
    	//Testing with range containing not a number
    	@Test
    	public void forRangeWithNaN() {
    		assertEquals(-1089994752, lowerNaNRange.hashCode());
    	}
    	
		//Testing for null range, should throw exception 
    	@Test(expected = Exception.class)
    	public void forNullRange() {
    		Range testRange = null;
    		testRange.hashCode();
    	}
    }

    //Testing the scale() function in the Range class
    public static class scaleTest {

		//Testing with null range
    	@Test(expected = IllegalArgumentException.class)
    	public void forNullRange() {
    		Range.scale(null, 1);
    	}
    	
		//Testing for scale with factor less than 0
    	@Test(expected = IllegalArgumentException.class)
    	public void factorLessThanZero() {
    		Range.scale(exampleRange, -1);
    	}
    	
		//Testing for scale with factor of 2
    	@Test
    	public void factorByTwo() {
    		Range scaledRange = Range.scale(exampleRange, 2);
    		assertEquals(new Range(-2,2), scaledRange);
    	}
    }
    
	//Testing the eqauls() function in the Range class
    public static class equalsTest{

		//Testing with valid range
    	@Test
    	public void forValidRanges() {
    		Range testRange = new Range(-1,1);
    		assertTrue(exampleRange.equals(testRange));
    	}
    	
		//Testing with a non range object
    	@Test
    	public void forANonRangeObject() {
    		Object testRange = new Integer(1);
    		assertFalse(exampleRange.equals(testRange));
    	}
    	

		//Testing with ranges with different upper bounds
    	@Test
    	public void forRangesWithDifferentUpperBounds() {
    		Range testRange = new Range(-1,3);
    		assertFalse(exampleRange.equals(testRange));
    	}
    	
		//Testing with ranges with different lower bounds
    	@Test
    	public void forRangesWithDifferentLowerBounds() {
    		Range testRange = new Range(-3,1);
    		assertFalse(exampleRange.equals(testRange));
    	}
    	
    }
    
	//Testing the expandToInclude() function in the Range class
    public static class expandToIncludeTest {

		//Testing with null range
    	@Test
    	public void forNullRange() {
    		assertEquals(new Range(0,0), Range.expandToInclude(null, 0));
    	}
    	
    	//Testing with value greater than the upper bound
    	@Test
    	public void forValueGreaterThanUpperBound() {
    		assertEquals(new Range(-1.0,3.0), Range.expandToInclude(exampleRange, 3.0));
    	}
    	
		//Testing with value lower 
    	@Test
    	public void forValueLowerThanLowerBound() {
    		assertEquals(new Range(-3.0,1.0), Range.expandToInclude(exampleRange, -3.0));
    	}
    	
		//Testing twith value in range
    	@Test
    	public void forValueInRange() {
    		assertEquals(new Range(-1.0,1.0), Range.expandToInclude(exampleRange, 0.0));
    	}
    }
    

	//Testing the expand()) function in the Range class
    public static class expandTest{
    	
		//Testing with null range, should throw exception
    	@Test(expected = IllegalArgumentException.class)
    	public void forNullRange() {
    		Range.expand(null, 1 ,2);
    	}
    	
		//Testing with lower and greater than upper
    	@Test
    	public void forLowerGreaterThanUpper() {
    		assertEquals(new Range(6.0,6.0), Range.expand(exampleRange, -5, 1));
    	}

		//Testing for lower less than the upper
    	@Test
    	public void forLowerLessThanUpper() {
    		assertEquals(new Range(-3.0,3.0), Range.expand(exampleRange, 1, 1));
    	}

		//Testing for lower equal to the upper
    	@Test
    	public void forLowerEqualToUpper() {
    		assertEquals(new Range(-1.0,1.0), Range.expand(exampleRange, 0, 0));
    	}
    }
    
	//Testing the shift() function in the Range class
    public static class shiftWithBoolean{

		//Testing with null range, should throw exception
    	@Test(expected = IllegalArgumentException.class)
    	public void forNullRange() {
    		Range.shift(null, 1 , false);
    	}
    	
		//Testing shift with no zero crossing
    	@Test
    	public void shiftWithNoZeroCrossing() {
    		assertEquals(new Range(0.0,2.0), Range.shift(exampleRange, 1, false));
    	}
    	
		//Testing shift with no zero crossing with a range having a bound of zero
    	@Test
    	public void shiftWithNoZeroCrossingWithARangeHavingABoundOfZero() {
    		Range testRange = new Range(0.0, 2.0);
    		assertEquals(new Range(1.0,3.0), Range.shift(testRange, 1, false));
    	}
    	
		//Testing shift with zero crossing
    	@Test
    	public void shiftWithZeroCrossing() {
    		assertEquals(new Range(0.0,2.0), Range.shift(exampleRange, 1, true));
    	}
    }
    
	//Testing the shift() function in the Range class
    public static class shift{

		//Testing for null range, should throw exception
    	@Test(expected = IllegalArgumentException.class)
    	public void forNullRange() {
    		Range.shift(null, 1);
    	}
    	
		//Testing shift with no zero crossing
    	@Test
    	public void shiftWithNoZeroCrossing() {
    		assertEquals(new Range(0.0,2.0), Range.shift(exampleRange, 1));
    	}
    	
		//Testing shift with no zero crossing with a range having a bound of zero
    	@Test
    	public void shiftWithNoZeroCrossingWithARangeHavingABoundOfZero() {
    		Range testRange = new Range(0.0, 2.0);
    		assertEquals(new Range(1.0,3.0), Range.shift(testRange, 1));
    	}
    }
    
    @After
    public void tearDown() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
    
}
    
   
    
    
    
