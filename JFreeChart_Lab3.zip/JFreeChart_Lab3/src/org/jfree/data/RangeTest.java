package org.jfree.data;

import static org.junit.Assert.*;

import java.security.InvalidParameterException;

import org.jfree.data.Range;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.*;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;





@RunWith(Enclosed.class)
public class RangeTest {
	
    private static Range exampleRange;
    private static Range upperNaNRange;
    private static Range lowerNaNRange;
    
    @BeforeClass public static void setUpBeforeClass() throws Exception {
    	exampleRange = new Range(-1, 1); // first is lower than second
    	upperNaNRange = new Range(-1, Double.NaN);
    	lowerNaNRange = new Range(Double.NaN, 1);
   
    	
    }


    @Before
    public void setUp() throws Exception {
    	
    	
    }
    
   
   

   public static class lengthTesting {
	   
	   //This tests if the length would be 2
	   @Test
	    public void lengthShouldBeTwo() {
	    	assertEquals("The length of -1 and 1 should be 2", 
	    	        2.0, exampleRange.getLength(), .000000001d);
	    }
	   
	   
	   @Test(expected = IllegalArgumentException.class)
	   public void lengthShouldNotBeCalculated() {
		    Range a = new Range(4, 3);
		    a.getLength(); 
	    	
	    }
	   
	   @Test
	   public void lengthShouldBeZero() {
		    Range b  = new Range(4, 4);
		    assertEquals("Length should be zero", 
	    	        0.0, exampleRange.getLength(), .000000001d);
	    	
	    }
	   
   }

    
    
 //This tests if the central value would zero
    public static class centralValueTesting{
    	 @Test
    	 public void centralValueShouldBeZero() {
    	     assertEquals("The central value of -1 and 1 should be 0",
    	      0, exampleRange.getCentralValue(), .000000001d);
    	  }
    	 
    	 
    }
   
   //This one tests the contains() method
    public static class containsTesting {
    	
    		// This one tests if zero is contained in -1 and 1
    		//should assert true
    	 	@Test
    	    public void containsInRange() {
    	    	assertTrue("Zero should be in range -1 and 1",exampleRange.contains(0.0));
    	    }
    	    
    	 // This one tests if the lower bound is contained in -1 and 1
    	 	//should assert true
    	 	@Test
    	 	public void containsLowerBound() {
    	    	assertTrue("-1 should be in range -1 and 1",exampleRange.contains(-1.0));
    	    }
    	 	
    	 // This one tests if the upper bound is contained in -1 and 1
    	 	//should assert true
    	 	@Test
    	 	public void containsUpperBound() {
    	    	assertTrue("1 should be in range -1 and 1",exampleRange.contains(1.0));
    	    }
    	 	
    	 	@Test
    	 	public void containsNaN() {
    	    	assertFalse("Double.NaN should be in range -1 and 1",exampleRange.contains(Double.NaN));
    	    }
    	 	
    	 	
    	 	
    	    
    	   // This one test if the values lower than the lower bound is  not contained in -1 and 1
    	 	//should assert false
    	    @Test
    	    public void containsLessThanLowerBound() {
    	    	assertFalse("-3 should not be in range -1 and 1",exampleRange.contains(-3.0));
    	    }
    	    
    	    // This one test if the values greater than the upper bound is  not contained in -1 and 1
    	  //should assert false
    	    @Test
    	    public void containsMoreThanUpperBound() {
    	    	assertFalse("3 should not be in range -1 and 1",exampleRange.contains(3.0));
    	    }
    	    
    	    @Test
    	    public void containsMoreThanUpperBoundWhenUpperIsNaN() {
    	    	assertFalse("3 should not be in range -1 and NaN",upperNaNRange.contains(3.0));
    	    }
    	    
    	    @Test
    	    public void containsLessThanLowerBoundWhenLowerIsNaN() {
    	    	assertFalse("-3 should not be in range NaN and 1",lowerNaNRange.contains(-3.0));
    	    }
    	    
    	    
    	    
    }
    
    public static class intersectWithRangeAsArgumentTest {
    	
    	//testing with boundaries  within -1 and 1
   	 	//should  be valid
    	 @Test
    	    public void intersectWithValuesWithinBoundary() {
    	    	assertTrue("-0.5 and 0 should intersect -1 and 1",
    	    	        exampleRange.intersects(new Range(-0.5,0)));
    	    }
    	 
    	//testing with range boundaries 
    	 //should not be valid
    	 @Test
    	 public void intersectWithRangeBoundaries() {
    		 assertTrue("-1 and 1 should intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-1,1)));
 	    
    	 }
    	 
    	 //testing with only lower value in range
    	 //should assert false
    	 @Test
    	 public void intersectWithOnlyLowerValueInRange() {
 	    	assertFalse("0 and 5 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(0,5)));
 	    }
    	 
    	 //testing with only upper value in range
    	 //should assert false
    	 @Test
    	 public void intersectWithOnlyUpperValueInRange() {
 	    	assertFalse("-5 and 0 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-5,0)));
    	 }
 	    
    	 //testing with both boundaries greater than 1
    	 //should assert false
    	 @Test
    	 public void intersectWithBothValuesMoreThanUpperBoundary() {
 	    	assertFalse("3 and 10 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-1,1)));
 	    }
    	 
    	 //testing with both boundaries less than -1
    	 //should assert false
    	 @Test
    	 public void intersectWithBothValuesLessThanLowerBoundary() {
 	    	assertFalse("-5 and -3 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-5,-3)));
 	    	
 	    }
    	 
    	 
    	 
    	 @Test
    	 public void intersectWithBothValuesLessThanLowerBoundaryAndGreaterThanUpperBoundary() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(-2,2)));
 	    	
 	    }
    	 
    	 
    	
    	 @Test
    	 public void intersectWithFirstValueNaN() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(Double.NaN,0)));
 	    	
 	    }
    	 
    	 @Test
    	 public void intersectWithSecondValueNaN() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(new Range(0,Double.NaN)));
 	    	
 	    }
    	 
    	 
    	
    }
    
    public static class constrainTest {
    	@Test
    	public void constrainForValueInRange() {
    		assertEquals("The constrain value of -1 and 1 should be 0",
    	    	      0, exampleRange.constrain(0), .000000001d);
    	}
    	
    	@Test
    	public void constrainForValueLowerThanLowerBound() {
    		assertEquals("The constrain value of -1 and 1 should be -1",
    	    	      -1.0, exampleRange.constrain(-3.0), .000000001d);
    	}
    	
    	@Test
    	public void constrainForValueLowerThanUpperBound() {
    		assertEquals("The constrain value of -1 and 1 should be 1",
    	    	      1.0, exampleRange.constrain(3.0), .000000001d);
    	}
    	
    	@Test
    	public void constrainForNaN() {
    		assertTrue(Double.isNaN(exampleRange.constrain(Double.NaN)));
    	}
    	
    	
    	
    }
    
    
    public static class isNanRangeTest {
    	@Test
    	public void testForValidRange() {
    		assertFalse((new Range(-1,1)).isNaNRange());
    	}
    	
    	@Test
    	public void testForUpperBoundNaNOnly() {
    		assertFalse((new Range(-1,Double.NaN)).isNaNRange());
    	}
    	
    	@Test
    	public void testForLowerBoundNaNOnly() {
    		assertFalse((new Range(Double.NaN,1)).isNaNRange());
    	}
    	
    	
    	@Test
    	public void testForBothBoundsNaN() {
    		assertTrue((new Range(Double.NaN,Double.NaN)).isNaNRange());
    	}
    }

    
    public static class boundaryTesting{
    	
    	//checks if lower bound is -1
    	@Test
        public void lowerBoundShouldBeNegativeOne() {
        	assertEquals("The lower bound of -1 and 1 should be -1",
        	        -1.0, exampleRange.getLowerBound(), .000000001d);
        }
        
    	
    	//checks if upper bound is 1
        @Test
        public void upperBoundShouldBeOne() {
        	assertEquals("The upper bound of -1 and 1 should be 1",
        	        1.0, exampleRange.getUpperBound(), .000000001d);
        }
    }
    
   public static class toStringTest{
	   @Test
	   public void forValidRange() {
		   assertEquals("It should be Range[-1.0,1.0]","Range[-1.0,1.0]", exampleRange.toString());
	   }
	   
	   @Test
	   public void forUpperBoundBeingNaNRange() {
		   assertEquals("It should be Range[-1.0,NaN]","Range[-1.0,NaN]", upperNaNRange.toString());
	   }
	   
	   @Test
	   public void forLowerBoundBeingNaNRange() {
		   assertEquals("It should be Range[NaN,1.0]","Range[NaN,1.0]", lowerNaNRange.toString());
	   }
   }
    
    public static class intersectingTest {
    	
    	
    	//testing with boundaries  within -1 and 1
   	 	//should  be valid
    	 @Test
    	    public void intersectWithValuesWithinBoundary() {
    	    	assertTrue("-0.5 and 0 should intersect -1 and 1",
    	    	        exampleRange.intersects(-0.5, 0));
    	    }
    	 
    	//testing with range boundaries 
    	 //should not be valid
    	 @Test
    	 public void intersectWithRangeBoundaries() {
    		 assertTrue("-1 and 1 should intersect -1 and 1",
 	    	        exampleRange.intersects(-1, 1));
 	    
    	 }
    	 
    	 //testing with only lower value in range
    	 //should assert false
    	 @Test
    	 public void intersectWithOnlyLowerValueInRange() {
 	    	assertFalse("0 and 5 should not intersect -1 and 1",
 	    	        exampleRange.intersects(0, 5));
 	    }
    	 
    	 //testing with only upper value in range
    	 //should assert false
    	 @Test
    	 public void intersectWithOnlyUpperValueInRange() {
 	    	assertFalse("-5 and 0 should not intersect -1 and 1",
 	    	        exampleRange.intersects(-5, 0));
    	 }
 	    
    	 //testing with both boundaries greater than 1
    	 //should assert false
    	 @Test
    	 public void intersectWithBothValuesMoreThanUpperBoundary() {
 	    	assertFalse("3 and 10 should not intersect -1 and 1",
 	    	        exampleRange.intersects(3, 10));
 	    }
    	 
    	 //testing with both boundaries less than -1
    	 //should assert false
    	 @Test
    	 public void intersectWithBothValuesLessThanLowerBoundary() {
 	    	assertFalse("-5 and -3 should not intersect -1 and 1",
 	    	        exampleRange.intersects(-5, -3));
 	    	
 	    }
    	 
    	 //testing with boundaries Less Than -1 And greater Than 1
    	 //should not be valid
    	 @Test
    	 public void intersectWithFirstValueGreaterSecondValue() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(5, 0));
 	    	
 	    }
    	 
    	 @Test
    	 public void intersectWithBothValuesLessThanLowerBoundaryAndGreaterThanUpperBoundary() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(-2, -2));
 	    	
 	    }
    	 
    	 
    	
    	 @Test
    	 public void intersectWithFirstValueNaN() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(Double.NaN, 0));
 	    	
 	    }
    	 
    	 @Test
    	 public void intersectWithSecondValueNaN() {
 	    	assertFalse("-2 and 2 should not intersect -1 and 1",
 	    	        exampleRange.intersects(0, Double.NaN));
 	    	
 	    }
    	 
    	 
    	 
    	 
    	 
    }
    
    
    public static class combineTest {
    	@Test
    	public void forValidRanges() {
    		
    		Range newRange = Range.combine( exampleRange, new Range(3 ,5));
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 5,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithFirstRangeNull() {
    		Range newRange = Range.combine(null,  exampleRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithSecondRangeNull() {
    		Range newRange = Range.combine( exampleRange, null);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithBothRangesNull() {
    		Range newRange = Range.combine( null , null);
    		assertNull(newRange);
    	}
    	
    }
    
   
    public static class combineIgnoringNaNTest {
    	@Test
    	public void forValidRanges() {
    		
    		Range newRange = Range.combineIgnoringNaN( exampleRange, new Range(3 ,5));
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 5,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithFirstRangeNull() {
    		Range newRange = Range.combineIgnoringNaN(null,  exampleRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithSecondRangeNull() {
    		Range newRange = Range.combineIgnoringNaN( exampleRange, null);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithBothRangesNull() {
    		Range newRange = Range.combineIgnoringNaN( null , null);
    		assertNull(newRange);
    	}
    	
    	@Test
    	public void forRangesWithSecondRangeWithLowerBoundNaN() {
    		Range newRange = Range.combineIgnoringNaN(exampleRange , lowerNaNRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	
    	@Test
    	public void forRangesWithFirstRangeWithLowerBoundNaN() {
    		Range newRange = Range.combineIgnoringNaN(lowerNaNRange, exampleRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithFirstRangeWithUpperBoundNaN() {
    		Range newRange = Range.combineIgnoringNaN(upperNaNRange , exampleRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithSecondRangeWithUpperBoundNaN() {
    		Range newRange = Range.combineIgnoringNaN(exampleRange, upperNaNRange);
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithOneRangeWithUpperBoundNaNAndOneNullRange() {
    		Range newRange = Range.combineIgnoringNaN(null, upperNaNRange );
    		assertEquals( -1,newRange.getLowerBound(), .000000001d );
    		assertEquals( Double.NaN,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithOneRangeWithLowerBoundNaNAndOneNullRange() {
    		Range newRange = Range.combineIgnoringNaN( lowerNaNRange, null);
    		assertEquals( Double.NaN,newRange.getLowerBound(), .000000001d );
    		assertEquals( 1.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithFirstRangeNUllAndSecondRangeWithNaNValues() {
    		Range newRange = Range.combineIgnoringNaN( null, new Range(Double.NaN, Double.NaN));
    		assertNull(newRange);
    	}
    	
    	@Test
    	public void forRangesWithSecondRangeNullAndSecondRangeWithNaNValues() {
    		Range newRange = Range.combineIgnoringNaN(new Range(Double.NaN, Double.NaN), null);
    		assertNull(newRange);
    	}
    	
    	@Test
    	public void forRangesWithNaNLowerBounds() {
    		Range newRange = Range.combineIgnoringNaN(new Range(Double.NaN, 1), new Range(Double.NaN, 3) );
    		assertEquals( Double.NaN,newRange.getLowerBound(), .000000001d );
    		assertEquals( 3.0,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithNaNUpperBounds() {
    		Range newRange = Range.combineIgnoringNaN(new Range( 1, Double.NaN), new Range( 3, Double.NaN) );
    		assertEquals(1.0 ,newRange.getLowerBound(), .000000001d );
    		assertEquals( Double.NaN,newRange.getUpperBound(), .000000001d );
    	}
    	
    	@Test
    	public void forRangesWithNaNBounds() {
    		Range newRange = Range.combineIgnoringNaN(new Range( Double.NaN, Double.NaN), new Range( Double.NaN, Double.NaN) );
    		assertNull(newRange);
    	}
    }
    
    public static class hashCodeTest{
    	@Test
    	public void forValidRange() {
    		assertEquals(-31457280, exampleRange.hashCode());
    	}
    	
    	
    	@Test
    	public void forRangeWithNaN() {
    		assertEquals(-1089994752, lowerNaNRange.hashCode());
    	}
    	
    	@Test(expected = Exception.class)
    	public void forNullRange() {
    		Range testRange = null;
    		testRange.hashCode();
    	}
    }
    
    public static class scaleTest {
    	@Test(expected = IllegalArgumentException.class)
    	public void forNullRange() {
    		Range.scale(null, 1);
    	}
    	
    	@Test(expected = IllegalArgumentException.class)
    	public void factorLessThanZero() {
    		Range.scale(exampleRange, -1);
    	}
    	
    	@Test
    	public void factorByTwo() {
    		Range scaledRange = Range.scale(exampleRange, 2);
    		assertEquals(new Range(-2,2), scaledRange);
    	}
    }
    
    public static class equalsTest{
    	@Test
    	public void forValidRanges() {
    		Range testRange = new Range(-1,1);
    		assertTrue(exampleRange.equals(testRange));
    	}
    	
    	@Test
    	public void forANonRangeObject() {
    		Object testRange = new Integer(1);
    		assertFalse(exampleRange.equals(testRange));
    	}
    	
    	@Test
    	public void forRangesWithDifferentUpperBounds() {
    		Range testRange = new Range(-1,3);
    		assertFalse(exampleRange.equals(testRange));
    	}
    	
    	@Test
    	public void forRangesWithDifferentLowerBounds() {
    		Range testRange = new Range(-3,1);
    		assertFalse(exampleRange.equals(testRange));
    	}
    	
    }
    
    public static class expandToIncludeTest {
    	@Test
    	public void forNullRange() {
    		assertEquals(new Range(0,0), Range.expandToInclude(null, 0));
    	}
    	
    	
    	@Test
    	public void forValueGreaterThanUpperBound() {
    		assertEquals(new Range(-1.0,3.0), Range.expandToInclude(exampleRange, 3.0));
    	}
    	
    	@Test
    	public void forValueLowerThanLowerBound() {
    		assertEquals(new Range(-3.0,1.0), Range.expandToInclude(exampleRange, -3.0));
    	}
    	
    	@Test
    	public void forValueInRange() {
    		assertEquals(new Range(-1.0,1.0), Range.expandToInclude(exampleRange, 0.0));
    	}
    }
    
    public static class expandTest{
    	
    	@Test(expected = IllegalArgumentException.class)
    	public void forNullRange() {
    		Range.expand(null, 1 ,2);
    	}
    	
    	@Test
    	public void forLowerGreaterThanUpper() {
    		assertEquals(new Range(6.0,6.0), Range.expand(exampleRange, -5, 1));
    	}
    	@Test
    	public void forLowerLessThanUpper() {
    		assertEquals(new Range(-3.0,3.0), Range.expand(exampleRange, 1, 1));
    	}
    	@Test
    	public void forLowerEqualToUpper() {
    		assertEquals(new Range(-1.0,1.0), Range.expand(exampleRange, 0, 0));
    	}
    }
    
    public static class shiftWithBoolean{
    	@Test(expected = IllegalArgumentException.class)
    	public void forNullRange() {
    		Range.shift(null, 1 , false);
    	}
    	
    	@Test
    	public void shiftWithNoZeroCrossing() {
    		assertEquals(new Range(0.0,2.0), Range.shift(exampleRange, 1, false));
    	}
    	
    	@Test
    	public void shiftWithNoZeroCrossingWithARangeHavingABoundOfZero() {
    		Range testRange = new Range(0.0, 2.0);
    		assertEquals(new Range(1.0,3.0), Range.shift(testRange, 1, false));
    	}
    	
    	@Test
    	public void shiftWithZeroCrossing() {
    		assertEquals(new Range(0.0,2.0), Range.shift(exampleRange, 1, true));
    	}
    }
    
    public static class shift{
    	@Test(expected = IllegalArgumentException.class)
    	public void forNullRange() {
    		Range.shift(null, 1);
    	}
    	
    	@Test
    	public void shiftWithNoZeroCrossing() {
    		assertEquals(new Range(0.0,2.0), Range.shift(exampleRange, 1));
    	}
    	
    	@Test
    	public void shiftWithNoZeroCrossingWithARangeHavingABoundOfZero() {
    		Range testRange = new Range(0.0, 2.0);
    		assertEquals(new Range(1.0,3.0), Range.shift(testRange, 1));
    	}
    }
    
    @After
    public void tearDown() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
    
    
   
    
    
    
}
