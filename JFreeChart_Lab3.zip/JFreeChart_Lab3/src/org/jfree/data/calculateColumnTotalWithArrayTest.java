package org.jfree.data;

import static org.junit.Assert.*;

import java.security.InvalidParameterException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class calculateColumnTotalWithArrayTest {

	private Mockery mockingContext;
	private Values2D values;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		mockingContext = new Mockery();
	    values = mockingContext.mock(Values2D.class);
	}

	

	@After
	public void tearDown() throws Exception {
		values = null;
		mockingContext = null;
	}

	
	
	
	
	/*** Here starts calculateColumnTotal for 2 valid values with a  valid array***/
	//			   |7.5| 
	//			   |2.5|
	@Test
	public void calculateColumnTotalForTwoValues() {
		mockingContext.checking(new Expectations() {
	        {   //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(2)); 
	            one(values).getValue(0, 0);
	            will(returnValue(7.5));
	            one(values).getValue(1, 0);
	            will(returnValue(2.5));
	            
	        }
	    });
		int validArray[] = {0,1};
	    double result = DataUtilities.calculateColumnTotal(values, 0, validArray);
	    assertEquals("Should return ten",10, result, .000000001d); 
		
	}
	
	
	/*** Here starts calculateColumnTotal for 2 negative valid values with a  valid array ***/
	//			   |-7.5|
	//             |-2.5|
	@Test
	public void calculateColumnTotalForNegativeTwoValues() {
		mockingContext.checking(new Expectations() {
	        {  //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(2));
	            one(values).getValue(0, 0);
	            will(returnValue(-7.5));
	            one(values).getValue(1, 0);
	            will(returnValue(-2.5));
	            
	        }
	    });
		int validArray[] = {0,1};
	    double result = DataUtilities.calculateColumnTotal(values, 0, validArray);
	    assertEquals("Should return negative ten",-10, result, .000000001d);
		
	}
	
	/*** Here starts calculateColumnTotal for 5 valid values  with a  valid array***/
	//			   |7.5 |
//				   |-2.5| 
//				   |2.5 |
//				   |7.5 |
//				   |1.0 |
	@Test
	public void calculateColumnTotalFiveValues() {
		mockingContext.checking(new Expectations() {
	        {	 //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(5));
	            one(values).getValue(0, 0);
	            will(returnValue(7.5));
	            one(values).getValue(1, 0);
	            will(returnValue(-2.5));
	            one(values).getValue(2, 0);
	            will(returnValue(2.5));
	            one(values).getValue(3, 0);
	            will(returnValue(-7.5));
	            one(values).getValue(4, 0);
	            will(returnValue(1.0));
	            
	            
	        }
	    });
		int validArray[] = {0,1,2,3,4};
	    double result = DataUtilities.calculateColumnTotal(values, 0, validArray);
	    assertEquals("Should return 1.0",1.0, result, .000000001d);
		
	}
	
	/*** Here starts calculateColumnTotal for 1 valid value ***/
	//	 |7.5 |
	@Test
	public void calculateColumnTotalOneValue() {
		mockingContext.checking(new Expectations() {
	        {	 //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(1));
	            one(values).getValue(0, 0);
	            will(returnValue(7.5));
	            
	            
	            
	        }
	    });
		int validArray[] = {0};
	    double result = DataUtilities.calculateColumnTotal(values, 0, validArray);
	    assertEquals("Should return 7.5",7.5, result, .000000001d);
		
	}
	
	
	/*** Here starts calculateColumnTotal for 1 valid value ***/
	//	 |0|
	//   |0|
	@Test
	public void calculateColumnTotalWithAllZeros() {
		mockingContext.checking(new Expectations() {
	        {	 //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(1));
	            one(values).getValue(0, 0);
	            will(returnValue(0));
	            one(values).getValue(0, 1);
	            will(returnValue(0));
	            
	            
	            
	        }
	    });
		int validArray[] = {0};
	    double result = DataUtilities.calculateColumnTotal(values, 0, validArray);
	    assertEquals("Should return 0",0, result, .000000001d);
		
	}
	
	
	//valid input with 2 columns |7.5  7.5|
	@Test
	public void calculateColumnTotalForTwoColumns() {
		mockingContext.checking(new Expectations() {
	        {	 //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(1));
	            one(values).getValue(0, 0);
	            will(returnValue(7.5));
	            one(values).getValue(0, 1);
	            will(returnValue(7.5));
	            
	            
	        }
	    });
		int validArray[] = {0};
	    double result = DataUtilities.calculateColumnTotal(values, 1, validArray);
	    assertEquals("Should return 7.5",7.5, result, .000000001d);
		
	}
	
	
	
	//invalid inputs |null| 
	//				 |null|
	//should print zero
	//valid array
	@Test(expected = InvalidParameterException.class)
	public void testingForTotalToBeZeroForInvalidInput() {
		mockingContext.checking(new Expectations() {
	        {    //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(2));
	            one(values).getValue(0, 0);
	            will(returnValue(1.0));
	            one(values).getValue(1, 0);
	            will(returnValue(null));
	            
	        }
	    });
		int validArray[] = {0,1};
	    DataUtilities.calculateColumnTotal(values, 0, validArray);
		
	}
	
	
	//invalid inputs |null|
	//				 |null|
	//should trigger InvalidParameterException
	@Test(expected = InvalidParameterException.class)
	public void testingForInvalidParameterExceptionForInvalidValue() {
		mockingContext.checking(new Expectations() {
	        {    //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(2));
	            one(values).getValue(0, 0);
	            will(returnValue(null));
	            one(values).getValue(1, 0);
	            will(returnValue(null));
	            
	        }
	    });
	    DataUtilities.calculateColumnTotal(values, 0);
	    
		
	}
	
	
	@Test
	public void calculateColumnTotalForZeroRowCount() {
		mockingContext.checking(new Expectations() {
	        {    //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(0));
	            
	            
	        }
	    });
		int validArray[] = {0};
	    double result = DataUtilities.calculateColumnTotal(values, 1, validArray);
	    assertEquals("Should return 0",0, result, .000000001d);
		
	}	
	
	
	@Test
	public void calculateColumnTotalForNegativeRowCount() {
		mockingContext.checking(new Expectations() {
	        {    //setting up return of those functions to the value
	            one(values).getRowCount();
	            will(returnValue(-1));
	            
	            
	        }
	    });
		int validArray[] = {0};
	    double result = DataUtilities.calculateColumnTotal(values, 1, validArray);
	    assertEquals("Should return 0",0, result, .000000001d);
		
	}	

	
	
	

	//null is passed in arguments
	//should trigger InvalidParameterException
	@Test(expected = InvalidParameterException.class)
	public void testingForInvalidParameterExceptionForInvalidValues2D() {
		
		try {
	    DataUtilities.calculateColumnTotal(null, 0, null);
		}
		catch(Exception e) {
			
		}
	}
	
}
